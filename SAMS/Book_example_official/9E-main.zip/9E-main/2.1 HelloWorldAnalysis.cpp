// Preprocessor directive that includes header iostream
#include <iostream>

// Start of your program: function block main()
int main()
{
    /* Write to the console output i.e. screen */
    std::cout << "Hello World" << std::endl;

    // Return a value to the OS
    return 0;
}
