// 31.2 SimpleOperations.cpp: module implementation unit

module SimpleOperations;

int AddIntegers(int a, int b)
{
   return (a + b);
}

int SubtractIntegers(int a, int b)
{
   return (a - b);
}

void FuncIsNotVisibleOutsideModule(){}
